import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import torchvision
import torchvision.transforms as transforms
import torchvision.models as models
import copy
from tqdm import tqdm

class EarlyStopping:
    def __init__(self, patience=3, min_delta=0.001):
        self.patience = patience
        self.min_delta = min_delta
        self.counter = 0
        self.best_loss = None
        self.best_model = None
        self.stopped = False

    def __call__(self, val_loss, model):
        if self.best_loss is None or val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.best_model = copy.deepcopy(model.state_dict())
            self.counter = 0
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.stopped = True
        return self.stopped

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()
    running_loss, correct, total = 0.0, 0, 0
    pbar = tqdm(enumerate(loader), total=len(loader), desc="Training", leave=False)
    
    for i, (images, labels) in pbar:
        images, labels = images.to(device), labels.to(device)
        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()
        
        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()
        
        if i % 10 == 0:
            pbar.set_postfix(loss=f"{loss.item():.4f}", acc=f"{(100. * correct / total):.2f}%")
            
    return running_loss / total, 100. * correct / total

def evaluate(model, loader, criterion, device):
    model.eval()
    running_loss, correct, total = 0.0, 0, 0
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            outputs = model(images)
            loss = criterion(outputs, labels)
            running_loss += loss.item() * images.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
    return running_loss / total, 100. * correct / total

def train_model(model, train_loader, test_loader, criterion, optimizer, device, num_epochs=3, model_name="Model"):
    early_stopping = EarlyStopping(patience=3)
    print(f"\n--- Starting: {model_name} ---")
    
    for epoch in range(1, num_epochs + 1):
        t_loss, t_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        v_loss, v_acc = evaluate(model, test_loader, criterion, device)
        print(f"Epoch [{epoch}/{num_epochs}] Train Loss: {t_loss:.4f} Acc: {t_acc:.2f}% | Val Loss: {v_loss:.4f} Acc: {v_acc:.2f}%")
        
        if early_stopping(v_loss, model):
            print("Early stopping triggered.")
            model.load_state_dict(early_stopping.best_model)
            break
    return v_acc

if __name__ == '__main__':
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")

    # Settings for CPU speed
    IMG_SIZE = 64 
    BATCH_SIZE = 32

    transform = transforms.Compose([
        transforms.Resize((IMG_SIZE, IMG_SIZE)),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    print("Loading Data...")
    train_ds = torchvision.datasets.CIFAR10(root='./data', train=True, download=True, transform=transform)
    test_ds = torchvision.datasets.CIFAR10(root='./data', train=False, download=True, transform=transform)

    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True, num_workers=0)
    test_loader = DataLoader(test_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)

    # --- 1. VGG16 Feature Extraction ---
    print("\nSetting up VGG16...")
    vgg = models.vgg16(weights=models.VGG16_Weights.IMAGENET1K_V1)
    for param in vgg.parameters():
        param.requires_grad = False
    
    # FIX: Use AdaptiveAvgPool2d to ensure output is always 7x7 before classifier
    vgg.avgpool = nn.AdaptiveAvgPool2d((7, 7))
    vgg.classifier = nn.Sequential(
        nn.Linear(512 * 7 * 7, 256),
        nn.ReLU(),
        nn.Dropout(0.4),
        nn.Linear(256, 10)
    )
    vgg = vgg.to(device)
    
    optimizer = optim.Adam(vgg.classifier.parameters(), lr=0.001)
    acc_vgg = train_model(vgg, train_loader, test_loader, nn.CrossEntropyLoss(), optimizer, device, num_epochs=2, model_name="VGG16 FE")

    # --- 2. ResNet50 Feature Extraction ---
    print("\nSetting up ResNet50...")
    resnet = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
    for param in resnet.parameters():
        param.requires_grad = False
    
    # ResNet already has an adaptive pool, just change the final layer
    resnet.fc = nn.Linear(2048, 10)
    resnet = resnet.to(device)
    
    optimizer_res = optim.Adam(resnet.fc.parameters(), lr=0.001)
    acc_res = train_model(resnet, train_loader, test_loader, nn.CrossEntropyLoss(), optimizer_res, device, num_epochs=2, model_name="ResNet50 FE")

    print("\n" + "="*30)
    print(f"VGG16 Accuracy: {acc_vgg:.2f}%")
    print(f"ResNet50 Accuracy: {acc_res:.2f}%")
    print("="*30)