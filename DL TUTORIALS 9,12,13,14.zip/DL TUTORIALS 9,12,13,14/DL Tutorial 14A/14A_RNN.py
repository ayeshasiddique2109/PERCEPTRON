import numpy as np
import os
os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2' 
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, SimpleRNN, Dense, Dropout, TimeDistributed
from tensorflow.keras.optimizers import Adam
from sklearn.preprocessing import LabelEncoder


sentences = [
    "Islamabad is the capital of Pakistan",
    "Ahmad works at Google",
    "NUST is a top university",
    "Robotics is fun to learn",
    "Elon Musk lives in Texas",
    "NUST is located in Islamabad",
    "Microsoft was founded by Bill Gates",
    "The robot is moving in the Lab",
    "Lahore is a city in Pakistan",
    "Jeff Bezos started Amazon",
    "Islamabad is a beautiful city", 
    "Ahmad lives in Lahore"          
]

labels = [
    ["LOCATION", "O", "O", "O", "O", "LOCATION"],
    ["PERSON", "O", "O", "ORGANIZATION"],
    ["ORGANIZATION", "O", "O", "O", "O"],
    ["O", "O", "O", "O", "O"],
    ["PERSON", "PERSON", "O", "O", "LOCATION"],
    ["ORGANIZATION", "O", "O", "O", "LOCATION"],
    ["ORGANIZATION", "O", "O", "O", "PERSON", "PERSON"],
    ["O", "O", "O", "O", "O", "O", "O"],
    ["LOCATION", "O", "O", "O", "O", "LOCATION"],
    ["PERSON", "PERSON", "O", "ORGANIZATION"],
    ["LOCATION", "O", "O", "O", "O"],
    ["PERSON", "O", "O", "LOCATION"]
]

# 2. Preprocessing [cite: 26, 39, 44, 46, 51]
tokenizer = Tokenizer(lower=True)
tokenizer.fit_on_texts(sentences)
X = tokenizer.texts_to_sequences(sentences)
X = pad_sequences(X, padding='post')

label_encoder = LabelEncoder()
label_encoder.fit(["O", "PERSON", "LOCATION", "ORGANIZATION"])
y = [label_encoder.transform(label) for label in labels]
y = pad_sequences(y, padding='post', maxlen=X.shape[1])
y = np.expand_dims(y, -1)

# 3. Model Architecture (Task: Change units and learning rate) [cite: 58, 61, 63, 67, 90]
model = Sequential()
model.add(Embedding(input_dim=len(tokenizer.word_index) + 1, output_dim=50, input_length=X.shape[1]))
model.add(SimpleRNN(units=128, return_sequences=True))
model.add(Dropout(0.2))
model.add(TimeDistributed(Dense(len(label_encoder.classes_), activation="softmax")))

optimizer = Adam(learning_rate=0.005) 
model.compile(optimizer=optimizer, loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# 4. Training (Task: Increase epochs) [cite: 72, 90]
print("Training is starting...")
model.fit(np.array(X), np.array(y), epochs=100, batch_size=2, verbose=1)

# 5. Testing [cite: 77, 82, 86]
test_sentence = ["Ahmad is in Islamabad"]
test_seq = tokenizer.texts_to_sequences(test_sentence)
test_seq = pad_sequences(test_seq, padding='post', maxlen=X.shape[1])

predictions = model.predict(test_seq)
decoded_preds = label_encoder.inverse_transform(np.argmax(predictions, axis=-1)[0])

print("\n--- Final Optimized Results ---")
test_words = test_sentence[0].split()
for i in range(len(test_words)):
    print(f"Word: {test_words[i]} -> Predicted Label: {decoded_preds[i]}")