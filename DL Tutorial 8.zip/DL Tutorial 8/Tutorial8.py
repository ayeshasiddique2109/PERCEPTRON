import tensorflow as tf
from tensorflow import keras
import numpy as np
import cv2
import matplotlib.pyplot as plt

#Modified Backbone
def build_backbone(input_shape=(224, 224, 3)):
    inputs = keras.Input(shape=input_shape)
    x = keras.layers.Conv2D(64, (3, 3), activation='relu', padding='same')(inputs)
    x = keras.layers.MaxPooling2D((2, 2))(x)
    
    x = keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same')(x)
    x = keras.layers.Conv2D(128, (3, 3), activation='relu', padding='same')(x) 
    x = keras.layers.MaxPooling2D((2, 2))(x)
    
    x = keras.layers.Conv2D(256, (3, 3), activation='relu', padding='same')(x)
    x = keras.layers.MaxPooling2D((2, 2))(x)
    
    outputs = keras.layers.Conv2D(512, (3, 3), activation='relu', padding='same')(x)
    return keras.Model(inputs, outputs, name="backbone_modified")

#ROI Pooling & RPN Components 
class ROIPoolingLayer(tf.keras.layers.Layer):
    def __init__(self, pool_size, **kwargs):
        super(ROIPoolingLayer, self).__init__(**kwargs)
        self.pool_size = pool_size

    def call(self, inputs):
        feature_map, rois = inputs
        rois = tf.reshape(rois, (-1, 4))
        batch_indices = tf.zeros((tf.shape(rois)[0],), dtype=tf.int32)
        return tf.image.crop_and_resize(feature_map, rois, batch_indices, self.pool_size)

def build_rpn(feature_map_shape):
    inputs = keras.Input(shape=feature_map_shape)
    rpn_conv = keras.layers.Conv2D(512, (3, 3), padding="same", activation="relu")(inputs)
    rpn_class = keras.layers.Conv2D(18, (1, 1), activation="sigmoid")(rpn_conv)
    rpn_bbox = keras.layers.Conv2D(36, (1, 1))(rpn_conv)
    return keras.Model(inputs, [rpn_class, rpn_bbox])

def build_faster_rcnn(num_classes):
    input_img = keras.Input(shape=(224, 224, 3))
    input_rois = keras.Input(shape=(None, 4))
    
    backbone = build_backbone()
    features = backbone(input_img)
    
    # RPN Output
    rpn = build_rpn(features.shape[1:])
    rpn_cls, rpn_box = rpn(features)
    
    # ROI Pooling
    pooled = ROIPoolingLayer((7, 7))([features, input_rois])
    
    # Heads
    x = keras.layers.Flatten()(pooled)
    x = keras.layers.Dense(1024, activation='relu')(x)
    cls_out = keras.layers.Dense(num_classes, activation='softmax')(x)
    bbox_out = keras.layers.Dense(num_classes * 4)(x)
    
    return keras.Model(inputs=[input_img, input_rois], outputs=[cls_out, bbox_out])

#EVALUATION: Mean Average Precision (mAP)
def calculate_ap(precisions, recalls):
    """Calculates AP using the area under PR curve (Rectangular Integration)"""
    # Adding boundary points
    mrec = np.concatenate(([0.], recalls, [1.]))
    mpre = np.concatenate(([0.], precisions, [0.]))
    
    # Compute the precision envelope
    for i in range(len(mpre) - 1, 0, -1):
        mpre[i - 1] = np.maximum(mpre[i - 1], mpre[i])
        
    # Integration: Sum of (Delta Recall * Precision)
    i = np.where(mrec[1:] != mrec[:-1])[0]
    ap = np.sum((mrec[i + 1] - mrec[i]) * mpre[i + 1])
    return ap

#FINAL EXECUTION
num_classes = 2 
model = build_faster_rcnn(num_classes)
example_recalls = np.array([0.1, 0.2, 0.4, 0.6])
example_precisions = np.array([1.0, 0.9, 0.85, 0.80])

ap_score = calculate_ap(example_precisions, example_recalls)
print(f"Calculated Average Precision (AP): {ap_score:.4f}")
model.summary()