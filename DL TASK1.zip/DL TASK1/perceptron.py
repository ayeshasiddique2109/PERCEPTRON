import numpy as np
import pandas as pd
from sklearn.utils import shuffle
from sklearn.model_selection import train_test_split


class Perceptron(object):
    def __init__(self, eta=0.01, n_iter=10):
        # η (eta): the learning rate 
        self.eta = eta
        # n_iter: the number of iterations 
        self.n_iter = n_iter

    def weighted_sum(self, X):
        # Step 2 
        return np.dot(X, self.w_[1:]) + self.w_[0]

    def sigmoid(self, z):
        # Task 2
        return 1 / (1 + np.exp(-z))

    def predict(self, X):
        # Task 3
        phi_z = self.sigmoid(self.weighted_sum(X))
        return 1 if phi_z >= 0.5 else 0

    def fit(self, X, y):
        # Initializing weights to 0 
        # self.w_[0] is the bias 
        self.w_ = np.zeros(1 + X.shape[1])
        self.errors_ = []

        for _ in range(self.n_iter):
            errors = 0
            for xi, target in zip(X, y):
                # Calculate the weight update: ΔWi = η * (y - ŷ) * Xi 
                update = self.eta * (target - self.predict(xi))
                # Update weights W1 to Wn 
                self.w_[1:] += update * xi
                # Update bias W0 
                self.w_[0] += update
                # Track errors if prediction was incorrect
                errors += int(update != 0.0)
            self.errors_.append(errors)
        return self

# DATA PREPARATION 
# Loading the Iris dataset 
url = 'https://archive.ics.uci.edu/ml/machine-learning-databases/iris/iris.data'
df = pd.read_csv(url, header=None)
df = shuffle(df) # Randomize data order 

# Extracting the first four columns as features (X) 
X = df.iloc[:, 0:4].values
# Extracting the fifth column as target label (y) 
y = df.iloc[:, 4].values

# Task 3: Encoding labels: 1 for Iris-setosa, 0 otherwise 
y = np.where(y == 'Iris-setosa', 1, 0)

# Splitting data into 75% training and 25% testing 
train_data, test_data, train_labels, test_labels = train_test_split(X, y, test_size=0.25)

# --- TRAINING ---
# Initializing and training our Perceptron 
model = Perceptron(eta=0.1, n_iter=10)
model.fit(train_data, train_labels)
print("Model trained successfully.")

# TASK 1: MANUAL INPUT & PREDICTION 
def run_manual_test():
    print("\n--- Manual Iris Species Prediction ---")
    try:
        # Taking manual input for the four features 
        sl = float(input("Enter Sepal Length: "))
        sw = float(input("Enter Sepal Width: "))
        pl = float(input("Enter Petal Length: "))
        pw = float(input("Enter Petal Width: "))
        
        user_features = np.array([sl, sw, pl, pw])
        
        # Using the model to predict based on manual values 
        prediction = model.predict(user_features)
        
        # Displaying the result 
        if prediction == 1:
            print("\nPrediction: This flower is Iris-setosa.")
        else:
            print("\nPrediction: This flower is NOT Iris-setosa.")
            
    except ValueError:
        print("Error: Please enter numeric values for measurements.")

if __name__ == "__main__":
    run_manual_test()