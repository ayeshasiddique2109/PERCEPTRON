
import torch
import torchvision.models as models
import torchvision.transforms as transforms
from PIL import Image
import urllib.request
import json
import os


img_path = r"C:\Users\hp\Desktop\Task 6 DL\task 6.avif"  # <-- CHANGE THIS


print("Downloading ImageNet labels...")
labels_url = (
    "https://raw.githubusercontent.com/anishathalye/imagenet-simple-labels"
    "/master/imagenet-simple-labels.json"
)
with urllib.request.urlopen(labels_url) as response:
    labels = json.load(response)
print(f"Loaded {len(labels)} class labels.\n")

def preprocess_image(img_path):
    """
    Loads an image and converts it to a model-ready tensor.
    All torchvision pretrained models expect:
      - Size: 224 x 224
      - Normalized with ImageNet mean and std
      - Shape: (1, 3, 224, 224)  [batch, channels, height, width]
    """
    transform = transforms.Compose([
        transforms.Resize((224, 224)),
        transforms.ToTensor(),
        transforms.Normalize(
            mean=[0.485, 0.456, 0.406],
            std= [0.229, 0.224, 0.225]
        )
    ])
    img = Image.open(img_path).convert('RGB')
    return transform(img).unsqueeze(0)   # Add batch dimension


# NOTE: First run will download weights (~500 MB total). Cached after that.
print("Loading pretrained models (downloading weights if first time)...")

alexnet   = models.alexnet(weights=models.AlexNet_Weights.DEFAULT)
resnet50  = models.resnet50(weights=models.ResNet50_Weights.DEFAULT)
resnet101 = models.resnet101(weights=models.ResNet101_Weights.DEFAULT)
mobilenet = models.mobilenet_v2(weights=models.MobileNet_V2_Weights.DEFAULT)

# Switch to evaluation mode (disables dropout and batchnorm training behaviour)
for m in [alexnet, resnet50, resnet101, mobilenet]:
    m.eval()

print("All models loaded!\n")

def predict_top5(model, img_tensor, labels, model_name):
    """
    Runs inference and prints the top-5 class predictions.
    - softmax converts raw logits to probabilities (sum = 1)
    - topk returns 5 highest probability classes
    """
    with torch.no_grad():   # No gradient calculation needed for inference
        outputs = model(img_tensor)

    probs = torch.nn.functional.softmax(outputs[0], dim=0)
    top5_probs, top5_idx = torch.topk(probs, 5)

    print(f"{'='*50}")
    print(f"  Top 5 Predictions  -->  [{model_name}]")
    print(f"{'='*50}")
    for rank, (prob, idx) in enumerate(zip(top5_probs, top5_idx), 1):
        label = labels[idx.item()]
        print(f"  {rank}. {label:<35} {prob.item()*100:.2f}%")
    print()


if not os.path.exists(img_path):
    print(f"ERROR: Image not found at: {img_path}")
    print("Please update the img_path variable at the top of this script.")
else:
    print(f"Image: {img_path}\n")
    img_tensor = preprocess_image(img_path)

    model_dict = {
        "AlexNet"      : alexnet,
        "ResNet-50"    : resnet50,
        "ResNet-101"   : resnet101,
        "MobileNet-V2" : mobilenet,
    }

    for name, model in model_dict.items():
        predict_top5(model, img_tensor, labels, name)

    print("Done! All predictions complete.")