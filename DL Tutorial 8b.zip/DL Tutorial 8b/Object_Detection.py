import tensorflow as tf
from tensorflow import keras
import tensorflow_hub as hub
import numpy as np
import cv2
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import os

# LIBRARIES 
COCO_CLASSES = [
    "person","bicycle","car","motorcycle","airplane","bus","train","truck",
    "boat","traffic light","fire hydrant","stop sign","parking meter","bench",
    "bird","cat","dog","horse","sheep","cow","elephant","bear","zebra","giraffe",
    "backpack","umbrella","handbag","tie","suitcase","frisbee","skis","snowboard",
    "sports ball","kite","baseball bat","baseball glove","skateboard","surfboard",
    "tennis racket","bottle","wine glass","cup","fork","knife","spoon","bowl",
    "banana","apple","sandwich","orange","broccoli","carrot","hot dog","pizza",
    "donut","cake","chair","couch","potted plant","bed","dining table","toilet",
    "TV","laptop","mouse","remote","keyboard","cell phone","microwave","oven",
    "toaster","sink","refrigerator","book","clock","vase","scissors",
    "teddy bear","hair drier","toothbrush"
]

# LOAD PRETRAINED FASTER R-CNN 
print("=" * 60)
print("  Loading Faster R-CNN ResNet50 V1 from local cache ...")
print("=" * 60)
MODEL_URL = "https://tfhub.dev/tensorflow/faster_rcnn/resnet50_v1_640x640/1"
hub_model = hub.load(MODEL_URL)
print("  Loaded: Faster R-CNN ResNet50 V1  (Backbone 1: ResNet-50)\n")

# WO EXTRA BACKBONES (local Keras, weights already cached)
def build_detector(backbone_name="resnet50", num_classes=80):
    if backbone_name == "resnet50":
        base = keras.applications.ResNet50(
            include_top=False, weights="imagenet", input_shape=(224,224,3))
    else:
        base = keras.applications.MobileNetV2(
            include_top=False, weights="imagenet", input_shape=(224,224,3))
    base.trainable = False
    inp      = keras.Input(shape=(224,224,3))
    x        = base(inp, training=False)
    x        = keras.layers.GlobalAveragePooling2D()(x)
    x        = keras.layers.Dense(512, activation="relu")(x)
    x        = keras.layers.Dropout(0.3)(x)
    cls_out  = keras.layers.Dense(num_classes, activation="softmax", name="class_out")(x)
    bbox_out = keras.layers.Dense(num_classes*4, name="bbox_out")(x)
    return keras.Model(inp, [cls_out, bbox_out], name=f"detector_{backbone_name}")

print("Building Backbone 2: ResNet50 (Keras local) ...")
local_resnet = build_detector("resnet50")
print("Building Backbone 3: MobileNetV2 (Keras local) ...")
local_mobilenet = build_detector("mobilenetv2")
print("Done.\n")
print("-"*60)
local_resnet.summary()
print("-"*60)
local_mobilenet.summary()
print("-"*60)

# DETECTION FUNCTION
def detect_objects(image_path, model, threshold=0.5):
    image = cv2.imread(image_path)
    if image is None:
        raise FileNotFoundError(
            f"\nERROR: Cannot read image:\n  {image_path}\n"
            "Check the path is correct and the file exists.")
    image_rgb    = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    input_tensor = tf.convert_to_tensor(image_rgb, dtype=tf.uint8)[tf.newaxis,...]
    detections   = model(input_tensor)
    boxes        = detections['detection_boxes'][0].numpy()
    class_idx    = detections['detection_classes'][0].numpy().astype(int) - 1
    scores       = detections['detection_scores'][0].numpy()
    valid        = scores >= threshold
    return image_rgb, boxes[valid], class_idx[valid], scores[valid]

# STEP 4: DISPLAY FUNCTION 
def display_detections(image, boxes, class_indices, scores,
                       title="Detections", save_path=None):
    img  = image.copy()
    h, w = img.shape[:2]
    for i, box in enumerate(boxes):
        ymin,xmin,ymax,xmax = box
        l,r = int(xmin*w), int(xmax*w)
        t,b = int(ymin*h), int(ymax*h)
        cv2.rectangle(img, (l,t), (r,b), (0,255,0), 2)
        idx   = int(class_indices[i])
        label = COCO_CLASSES[idx] if 0<=idx<len(COCO_CLASSES) else "unknown"
        cv2.putText(img, f"{label}: {scores[i]*100:.1f}%",
                    (l, max(t-8,15)), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (0,255,0), 2)
    plt.figure(figsize=(12,8))
    plt.imshow(img)
    plt.title(title, fontsize=14, fontweight='bold')
    plt.axis('off')
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches='tight')
        print(f"  Saved annotated image → {save_path}")
    plt.show()

IMAGE_PATH = r"C:\Users\hp\Desktop\DL Tutorial 8b\test_image.jpg"
THRESHOLD  = 0.5

print("\n" + "="*60)
print(f"  Detecting objects in: {IMAGE_PATH}")
print(f"  Threshold: {THRESHOLD}")
print("="*60)

try:
    image_rgb, boxes, class_indices, scores = detect_objects(
        IMAGE_PATH, hub_model, threshold=THRESHOLD)

    if len(boxes) == 0:
        print("\n  No objects detected above threshold.")
        print("  Try lowering THRESHOLD to 0.3 and re-run.")
    else:
        print(f"\n  Faster R-CNN ResNet50 V1 — {len(boxes)} object(s) found:")
        print(f"  {'#':<4} {'Class':<22} {'Confidence':>12}")
        print(f"  {'-'*40}")
        for i in range(len(boxes)):
            idx   = int(class_indices[i])
            label = COCO_CLASSES[idx] if 0<=idx<len(COCO_CLASSES) else "unknown"
            print(f"  {i+1:<4} {label:<22} {scores[i]*100:>11.2f}%")

    display_detections(image_rgb, boxes, class_indices, scores,
                       title="Faster R-CNN ResNet50 V1 — Detections",
                       save_path="result_resnet50.jpg")

except FileNotFoundError as e:
    print(e)

# BACKBONE COMPARISON (image-level class scores)
def classify_with_backbone(image_path, keras_model, model_name, top_k=5):
    image = cv2.imread(image_path)
    if image is None:
        print(f"  Cannot read {image_path}"); return
    img_rgb    = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    img_rs     = cv2.resize(img_rgb, (224,224))
    inp        = tf.convert_to_tensor(img_rs[np.newaxis], dtype=tf.float32)/255.0
    cls_s, _   = keras_model(inp, training=False)
    cls_s      = cls_s.numpy()[0]
    top_idx    = np.argsort(-cls_s)[:top_k]
    print(f"\n  {model_name} — Top-{top_k} class scores:")
    print(f"  {'#':<4} {'Class':<22} {'Score':>8}")
    print(f"  {'-'*37}")
    for rank, idx in enumerate(top_idx, 1):
        label = COCO_CLASSES[idx] if idx<len(COCO_CLASSES) else "unknown"
        print(f"  {rank:<4} {label:<22} {cls_s[idx]:>8.4f}")

print("\n" + "="*60)
print("  Backbone Comparison on same image")
print("="*60)
try:
    classify_with_backbone(IMAGE_PATH, local_resnet,    "Backbone 2: ResNet50 (Keras)")
    classify_with_backbone(IMAGE_PATH, local_mobilenet, "Backbone 3: MobileNetV2 (Keras)")
except Exception as e:
    print(f"  Error: {e}")

# mAP EVALUATION
def calculate_iou(b1, b2):
    y1=max(b1[0],b2[0]); x1=max(b1[1],b2[1])
    y2=min(b1[2],b2[2]); x2=min(b1[3],b2[3])
    inter=max(0,y2-y1)*max(0,x2-x1)
    a1=(b1[2]-b1[0])*(b1[3]-b1[1]); a2=(b2[2]-b2[0])*(b2[3]-b2[1])
    union=a1+a2-inter
    return inter/union if union>0 else 0

def calculate_ap(precisions, recalls):
    mrec=np.concatenate(([0.],recalls,[1.]))
    mpre=np.concatenate(([0.],precisions,[0.]))
    for i in range(len(mpre)-1,0,-1): mpre[i-1]=max(mpre[i-1],mpre[i])
    idx=np.where(mrec[1:]!=mrec[:-1])[0]
    return float(np.sum((mrec[idx+1]-mrec[idx])*mpre[idx+1]))

def evaluate_map(model, image_paths, ground_truths,
                 num_classes=80, threshold=0.5, iou_threshold=0.5):
    class_preds={c:[] for c in range(num_classes)}
    class_gts  ={c:0  for c in range(num_classes)}
    for img_path,gt in zip(image_paths,ground_truths):
        try: _,pred_boxes,pred_cls,pred_scores=detect_objects(img_path,model,threshold=0.0)
        except FileNotFoundError: print(f"  Skipping: {img_path}"); continue
        gt_boxes=np.array(gt['boxes']); gt_classes=np.array(gt['classes'])
        matched=set()
        for c in range(num_classes): class_gts[c]+=int(np.sum(gt_classes==c))
        for idx in np.argsort(-pred_scores):
            pc=int(pred_cls[idx])
            if pc>=num_classes: continue
            best_iou=0; best_j=-1
            for j,gb in enumerate(gt_boxes):
                if gt_classes[j]==pc and j not in matched:
                    iou=calculate_iou(pred_boxes[idx],gb)
                    if iou>best_iou: best_iou=iou; best_j=j
            tp=1 if best_iou>=iou_threshold else 0
            if tp: matched.add(best_j)
            class_preds[pc].append((pred_scores[idx],tp))
    aps=[]
    for c in range(num_classes):
        preds=sorted(class_preds[c],key=lambda x:-x[0])
        if not preds or class_gts[c]==0: continue
        tp_c=fp_c=0; precs=[]; recs=[]
        for score,tp in preds:
            if tp: tp_c+=1
            else:  fp_c+=1
            precs.append(tp_c/(tp_c+fp_c)); recs.append(tp_c/class_gts[c])
        ap=calculate_ap(precs,recs); aps.append(ap)
        print(f"  Class '{COCO_CLASSES[c]:<20}' AP = {ap:.4f}")
    return float(np.mean(aps)) if aps else 0.0

# UPDATE GROUND TRUTH FOR YOUR IMAGE 
# boxes: normalised [ymin, xmin, ymax, xmax]  (0.0 to 1.0)
# classes: COCO 0-based  (0=person 2=car 15=cat 16=dog 7=truck)
# Example: if your image has a dog filling most of the frame:
#   {'boxes': [[0.05, 0.05, 0.95, 0.95]], 'classes': [16]}
eval_images = [IMAGE_PATH]
eval_gts    = [
    {'boxes': [[0.05, 0.05, 0.95, 0.95]], 'classes': [16]},  
]

print("\n" + "="*60)
print("  mAP Evaluation — Faster R-CNN ResNet50 V1 @ IoU=0.5")
print("="*60)
mAP = evaluate_map(hub_model, eval_images, eval_gts,
                   threshold=0.5, iou_threshold=0.5)
print(f"\n  mAP @ IoU=0.5 : {mAP:.4f}  ({mAP*100:.2f}%)")
print("="*60)
print("\nDone! Annotated image saved as result_resnet50.jpg")